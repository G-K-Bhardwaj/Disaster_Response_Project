#!/usr/bin/env python
# coding: utf-8

# # ML Pipeline Preparation
# Follow the instructions below to help you create your ML pipeline.
# ### 1. Import libraries and load data from database.
# - Import Python libraries
# - Load dataset from database with [`read_sql_table`](https://pandas.pydata.org/pandas-docs/stable/generated/pandas.read_sql_table.html)
# - Define feature and target variables X and Y

# In[1]:


# import libraries
import nltk
nltk.download(['punkt', 'wordnet', 'stopwords'])

import sqlalchemy as sqla
import pandas as pd
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, TfidfTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.model_selection import GridSearchCV
from sklearn.svm import LinearSVC
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold


# In[2]:


# load data from database
def load_data():
    engine = sqla.create_engine('sqlite:///Disaster_Response.db')
    df = pd.read_sql('SELECT * FROM Messages', engine)
    X = df['message']
    Y = df.iloc[:,4:]
    return X, Y


# In[3]:


X, Y = load_data()


# In[4]:


X.head()


# In[5]:


Y.head()


# ### 2. Write a tokenization function to process your text data

# In[6]:


def tokenize(text):
    
    # normalize case and remove punctuation
    text = re.sub(r"[^a-zA-Z0-9]", " ", text.lower())
    
    # tokenize text
    words = word_tokenize(text)
    tokens = [w for w in words if w not in stopwords.words("english")]
    
    # lemmatize andremove stop words
    lemmatizer = WordNetLemmatizer()
        
    clean_tokens = []
    for tok in tokens:
        clean_tok = lemmatizer.lemmatize(tok).lower().strip()
        clean_tokens.append(clean_tok)

    return clean_tokens


# In[7]:


for message in X[:5]:
    tokens = tokenize(message)
    print(message)
    print(tokens, '\n')


# ### 3. Build a machine learning pipeline
# This machine pipeline should take in the `message` column as input and output classification results on the other 36 categories in the dataset. You may find the [MultiOutputClassifier](http://scikit-learn.org/stable/modules/generated/sklearn.multioutput.MultiOutputClassifier.html) helpful for predicting multiple target variables.

# In[8]:



pipeline = Pipeline([
    ('text_pipeline', Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer())
    ])),
    ('clf', MultiOutputClassifier(RandomForestClassifier(n_estimators=100)))
])


# In[9]:


'''
pipeline = Pipeline([
    ('vect', TfidfVectorizer(tokenizer=tokenize)),
    ('clf', MultiOutputClassifier(RandomForestClassifier(random_state=42, n_jobs=-1)))
    ])
'''


# ### 4. Train pipeline
# - Split data into train and test sets
# - Train pipeline

# In[9]:


X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, random_state=42)
pipeline.fit(X_train, y_train)


# ### 5. Test your model
# Report the f1 score, precision and recall for each output category of the dataset. You can do this by iterating through the columns and calling sklearn's `classification_report` on each.

# In[10]:


def display_results(y_test, y_pred):
    
    for i, col in enumerate(y_test.columns.values):
        print(col)
        print(classification_report(y_test.loc[:,col], y_pred[:,i]))
    


# In[11]:


y_pred = pipeline.predict(X_test)

display_results(y_test, y_pred)


# ### 6. Improve your model
# Use grid search to find better parameters. 

# In[12]:


pipeline.get_params()


# In[20]:


skf = StratifiedKFold(n_splits=10)
parameters = {
    #'text_pipeline__vect__ngram_range': ((1, 1), (1, 2)),
    #~~'text_pipeline__vect__max_df': [0.5],
    #~~~'clf__estimator__max_features': (20, 50),
    #~~'clf__estimator__max_features': [20],
    #~~~'clf__estimator__min_samples_leaf': (1, 2, 10), 
    #~~'clf__estimator__min_samples_leaf': [10], 
    #~'clf__estimator__n_estimators': [50],
    #~'clf__estimator__max_depth': [5],
    #'clf__estimator__n_jobs': [3],
    #'clf__estimator__verbose': [1]
    
}
refit_score='precision_score'
cv = GridSearchCV(pipeline, param_grid=parameters, cv=, return_train_score=True, n_jobs=-1,verbose=1)


# In[13]:



parameters = {
    #'text_pipeline__vect__ngram_range': ((1, 1), (1, 2)),
    #~~'text_pipeline__vect__max_df': [0.5],
    'clf__estimator__max_features': (20, 50),
    #~~'clf__estimator__max_features': [20],
    'clf__estimator__min_samples_leaf': (1, 2, 10), 
    #~~'clf__estimator__min_samples_leaf': [10], 
    'clf__estimator__n_estimators': [150],
    #~~'clf__estimator__max_depth': [20],
    'clf__estimator__n_jobs': [6],
    'clf__estimator__verbose': [1]
    
}

cv = GridSearchCV(pipeline, param_grid=parameters, cv=5, n_jobs=6,verbose=1)


# ### 7. Test your model
# Show the accuracy, precision, and recall of the tuned model.  
# 
# Since this project focuses on code quality, process, and  pipelines, there is no minimum performance metric needed to pass. However, make sure to fine tune your models for accuracy, precision and recall to make your project stand out - especially for your portfolio!

# In[15]:


get_ipython().run_line_magic('pinfo', 'GridSearchCV')


# In[14]:


cv.fit(X_train, y_train)


# In[15]:


y_pred_cv = cv.predict(X_test)

display_results(y_test, y_pred_cv)


# ### 8. Try improving your model further. Here are a few ideas:
# * try other machine learning algorithms
# * add other features besides the TF-IDF

# In[17]:


from sklearn.ensemble import AdaBoostClassifier

pipeline2 = Pipeline([
    ('text_pipeline', Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer())
    ])),
    ('clf', MultiOutputClassifier(AdaBoostClassifier(n_estimators=100)))
])


# In[ ]:


'''
pipeline2 = Pipeline([
    ('vect', TfidfTransformer(tokenizer=tokenize)),
    ('clf', MultiOutputClassifier(LinearSVC(class_weight="balanced")))
])
'''


# In[34]:


'''
from sklearn.ensemble import AdaBoostClassifier
pipeline2 = Pipeline([
    ('vect', TfidfVectorizer(tokenizer=tokenize, )),
    ('clf', MultiOutputClassifier(AdaBoostClassifier(random_state=42)))
])
'''


# In[18]:


pipeline2.fit(X_train, y_train)


# In[19]:


y_pred2 = pipeline2.predict(X_test)

display_results(y_test, y_pred2)


# In[33]:


pipeline2.get_params()


# In[21]:


import pickle
# save the model to disk

pickle.dump(pipeline, open('pipeline1.pkl', 'wb'))
pickle.dump(pipeline2, open('pipeline2.pkl', 'wb'))


# In[ ]:





# ### 9. Export your model as a pickle file

# In[ ]:





# ### 10. Use this notebook to complete `train.py`
# Use the template file attached in the Resources folder to write a script that runs the steps above to create a database and export a model based on a new dataset specified by the user.

# In[ ]:




